# Pooled_risk_estimates #

rm(list = ls())

library(meta)
library(readxl)
library(tibble)
library(dplyr)
library(scales)
library(tidyverse)

setwd("~/Downloads/Analysis/Pooled_risk_estimates")

marker <- c("cIMT","CP","CACS","baPWV","cfPWV","low ABI","high ABI","CAVI","AIx","FMD","CEPCs","E-selectin","LTL")

outcome <- c("all-cause death","CV death","stroke","MI","MACE")

results_table <- data.frame(Marker=0,Outcome=0,Model=0,Study_n=0,Total_Est=0,LCI_Est=0,UCI_Est=0,p_Est=0,I2=0,p_Q=0,total_I2=0,total_p_Q=0,sub_diff=0)

for (j in 1:length(marker)){
  
  for(i in 1:5){
    
    dt <- read_xlsx("Risk_estimates.xlsx") %>% filter(Biomarker==marker[j]) %>% filter(Outcome==outcome[i])
    
    # At least 3 studies were available
    if(dim(dt)[1]>3){
      
      ####Random_effect_model####
      
        m.gen <- metagen(log(HR),
                         lower=log(LCI), upper=log(UCI),
                         studlab = Source,
                         data = dt,
                         sm = "HR", 
                         fixed = F,
                         random = T)
        
        results <- data.frame(
          Marker=marker[j],Outcome=outcome[i],Model="Random",
          Study_n=m.gen[["k"]],
          Total_Est=exp(m.gen[["TE.random"]]),
          LCI_Est=exp(m.gen[["lower.random"]]),
          UCI_Est=exp(m.gen[["upper.random"]]),
          p_Est=m.gen[["pval.random"]],
          I2=percent(m.gen[["I2"]]),
          p_Q=m.gen[["pval.Q"]],total_I2=NA,total_p_Q=NA,sub_diff=NA)
        results_table <- rbind(results_table,results)
        
        pdf(file=paste0(marker[j],"_",outcome[i],"_Forest_plot.pdf"), width = 12, height = 8)
        forest(m.gen, 
               layout = "JAMA",
               prediction = TRUE)
        dev.off()
      
      ####Preplanned_subgroup_analysis####
      
        var <- c("Sex","Hypertension","Diabetes","Cohort","NOS")
        for (k in 1:length(var)) {
          sub_dt <- dt %>% select(Source=Source,HR=HR,LCI=LCI,UCI=UCI,byvar=var[k]) %>% na.omit()
          a <- sub_dt %>% pull(byvar) %>% n_distinct()
          m.gen <- metagen(log(HR),
                           lower=log(LCI), upper=log(UCI),
                           studlab = Source,
                           data = sub_dt,
                           sm = "HR",
                           fixed = F,
                           random = T,
                           subgroup = byvar,
                           print.subgroup.name = F)
          
          for (b in 1:a) {
            results <- data.frame(
              Marker=marker[j],Outcome=outcome[i],Model=m.gen[["subgroup.levels"]][b],
              Study_n=m.gen[["k.w"]][[b]],
              Total_Est=exp(m.gen[["TE.random.w"]][[b]]),
              LCI_Est=exp(m.gen[["lower.random.w"]][[b]]),
              UCI_Est=exp(m.gen[["upper.random.w"]][[b]]),
              p_Est=m.gen[["pval.random.w"]][[b]],
              I2=percent(m.gen[["I2.w"]][[b]]),
              p_Q=m.gen[["pval.Q.w"]][[b]],
              total_I2=percent(m.gen[["I2"]]),total_p_Q=m.gen[["pval.Q"]],
              sub_diff=m.gen[["pval.Q.b.random"]])
            results_table <- rbind(results_table,results)
            
            pdf(file=paste0(marker[j],"_",outcome[i],"_Subgroup_analysis_by_",var[k],"_.pdf"), width = 12, height = 8)
            forest(m.gen,layout = "JAMA")
            dev.off()
          }
        }
      
      ####Leave-one-out####
        
        m.gen.inf <- metainf(m.gen,pooled = "random")
        
        pdf(file=paste0("",marker[j],"_",outcome[i],"_Sensitivity_analysis_Leave-one-out.pdf"), width = 12, height = 8)
        forest(m.gen.inf,
               layout = "JAMA",
        )
        dev.off()
        
        
      ####Fixed_effect_model####
          
          m.gen <- metagen(log(HR),
                           lower=log(LCI), upper=log(UCI),
                           studlab = Source,
                           data = dt,
                           sm = "HR", 
                           fixed = T,
                           random = T)
          
          results <- data.frame(
            Marker=marker[j],Outcome=outcome[i],Model="Fixed",
            Study_n=m.gen[["k"]],
            Total_Est=exp(m.gen[["TE.common"]]),
            LCI_Est=exp(m.gen[["lower.common"]]),
            UCI_Est=exp(m.gen[["upper.common"]]),
            p_Est=m.gen[["pval.common"]],
            I2=percent(m.gen[["I2"]]),
            p_Q=m.gen[["pval.Q"]],total_I2=NA,total_p_Q=NA,sub_diff=NA)
          results_table <- rbind(results_table,results)
          
          pdf(file=paste0(marker[j],"_",outcome[i],"_Sensitivity_analysis_Fixed_effect_model.pdf"), width = 12, height = 8)
          forest(m.gen)
          dev.off()
        
      ####Trim_and_fill####
    
          trf <- trimfill(m.gen)
          
          results <- data.frame(
            Marker=marker[j],Outcome=outcome[i],Model="trimfill",
            Study_n=trf[["k"]],
            Total_Est=exp(trf[["TE.random"]]),
            LCI_Est=exp(trf[["lower.random"]]),
            UCI_Est=exp(trf[["upper.random"]]),
            p_Est=trf[["pval.random"]],
            I2=percent(trf[["I2"]]),
            p_Q=trf[["pval.Q"]],total_I2=NA,total_p_Q=NA,sub_diff=NA)
          results_table <- rbind(results_table,results)
          
      ####Funnel_plot####
          
          pdf(file=paste0(marker[j],"_",outcome[i],"_Funnel_plot.pdf"), width = 6, height = 4)
          # Define fill colors for contour
          col.contour = c("gray75", "gray85", "gray95")
          funnel(trf, 
                 contour = c(0.9, 0.95, 0.99),
                 col.contour = col.contour)
          # Add a legend
          legend("topright",
                 legend = c("p < 0.1", "p < 0.05", "p < 0.01"),
                 fill = col.contour)
          dev.off()

      ####Egger_test####
          
        # At least 3 studies were available
        if(dim(dt)[1]>=10){
          
          pdf(file=paste0(marker[j],"_",outcome[i],"_Egger_test.pdf"), width = 12, height = 8)
          Egger <- metabias(m.gen,method.bias = "Egger",plotit = TRUE)
          dev.off()
          
          results <- data.frame(
            Marker=marker[j],Outcome=outcome[i],Model="Egger",
            Study_n=Egger[["p.value"]],
            Total_Est=exp(Egger[["x"]][["TE.random"]]),
            LCI_Est=exp(Egger[["x"]][["lower.random"]]),
            UCI_Est=exp(Egger[["x"]][["upper.random"]]),
            p_Est=Egger[["x"]][["pval.random"]],
            I2=percent(Egger[["x"]][["I2"]]),
            p_Q=Egger[["x"]][["pval.Q"]],total_I2=NA,total_p_Q=NA,sub_diff=NA)
          results_table <- rbind(results_table,results)
    }
    
    }
  }
}

write.csv(results_table,"Pooled_risk_estimates_results_table.csv")



